sap.ui.define([
	"test/com/sapUI5app/test/unit/controller/View1.controller"
], function () {
	"use strict";
});