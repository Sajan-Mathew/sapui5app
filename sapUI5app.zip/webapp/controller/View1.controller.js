sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("test.com.sapUI5app.controller.View1", {
		onInit: function () {

		}
	});
});